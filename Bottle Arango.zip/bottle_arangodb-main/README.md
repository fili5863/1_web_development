# bottle_arangodb
Install docker
In the terminal in vscode:
> docker compose up
